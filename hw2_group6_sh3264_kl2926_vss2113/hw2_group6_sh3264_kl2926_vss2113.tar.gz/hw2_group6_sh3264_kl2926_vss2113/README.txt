Homework 2
Group 6
Members: Seungwook Han sh3264 - Kathleen Lee kl2926 - Vlad Scherbich vss2113
