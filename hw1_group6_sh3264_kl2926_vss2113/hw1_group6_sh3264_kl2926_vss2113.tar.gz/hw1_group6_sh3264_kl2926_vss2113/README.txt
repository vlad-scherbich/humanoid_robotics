Seungwook Han (sh3264)
Kathleen Lee (kl2926)
Vladislav Scherbich (vss2113)
Humanoid Robots

The functionality of the subscriber and publisher works perfectly in terms of publishing the current time at a rate of 1Hz and receiving and appending the time to a txt file called hw1_out.txt. The location of the hw1_out.txt is specified to be '../../hw1_out.txt" relative to the script folder from which the scripts are running.
